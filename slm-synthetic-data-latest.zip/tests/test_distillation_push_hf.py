import json

import pytest

from slm_synth.distillation_sft.push_hf import (
    build_response_cluster_review_summary,
    count_and_validate_jsonl,
    discover_jsonl_files,
    discover_run_manifest,
    push_distillation_run,
    require_manifest_dataset_counts,
    require_publish_prompt_uniqueness,
    require_publish_resolved_response_clusters,
)


def _distillation_row(row_id="distill-1"):
    return {
        "id": row_id,
        "prompt": "What is 2 + 2?",
        "reasoning": None,
        "response": "4",
        "metadata": {
            "category": "direct_arithmetic",
            "difficulty": 1,
            "template_family": "integer_addition",
            "eval_family": "basic_arithmetic_qa",
        },
    }


def test_count_and_validate_distillation_jsonl_rejects_bad_public_row(tmp_path):
    dataset = tmp_path / "distill.jsonl"
    row = _distillation_row()
    row["teacher_model"] = "openai/gpt-4.1-mini"
    dataset.write_text(json.dumps(row) + "\n", encoding="utf-8")

    with pytest.raises(ValueError, match="forbidden field"):
        count_and_validate_jsonl(dataset)


def test_discover_distillation_jsonl_prefers_final_files_over_batch_shards(tmp_path):
    dataset_dir = tmp_path / "datasets"
    dataset_dir.mkdir()
    final_path = dataset_dir / "arithmetic.jsonl"
    batch_path = dataset_dir / "arithmetic.batch000001.jsonl"
    final_path.write_text(json.dumps(_distillation_row("distill-1")) + "\n", encoding="utf-8")
    batch_path.write_text(json.dumps(_distillation_row("distill-2")) + "\n", encoding="utf-8")

    assert discover_jsonl_files(dataset_dir) == [final_path]


@pytest.mark.parametrize(
    "dirname",
    ["scratch", "batches", "partials", "partial", "rejected", "retries", "retry", "provider", "provider_internal", "tmp"],
)
def test_discover_distillation_jsonl_ignores_internal_dirs(tmp_path, dirname):
    dataset_dir = tmp_path / "datasets"
    internal_dir = dataset_dir / dirname
    internal_dir.mkdir(parents=True)
    public_path = dataset_dir / "arithmetic.jsonl"
    internal_path = internal_dir / "arithmetic.jsonl"
    public_path.write_text(json.dumps(_distillation_row("distill-1")) + "\n", encoding="utf-8")
    internal_path.write_text(json.dumps(_distillation_row("distill-2")) + "\n", encoding="utf-8")

    assert discover_jsonl_files(dataset_dir) == [public_path]


def test_discover_run_manifest_selects_only_run_level_manifest(tmp_path):
    run_dir = tmp_path / "run"
    manifest_dir = run_dir / "manifests"
    manifest_dir.mkdir(parents=True)
    run_manifest = manifest_dir / "run.manifest.json"
    run_manifest.write_text(json.dumps({"datasets": []}), encoding="utf-8")
    (manifest_dir / "arithmetic.run.manifest.json").write_text(json.dumps({"signal": "arithmetic"}), encoding="utf-8")
    (manifest_dir / "arithmetic.batch000001.run.manifest.json").write_text(
        json.dumps({"signal": "arithmetic", "batch_number": 1}), encoding="utf-8"
    )

    assert discover_run_manifest(run_dir) == run_manifest


def test_push_distillation_run_uploads_only_public_surface_files(tmp_path, monkeypatch):
    run_dir = tmp_path / "run"
    dataset_dir = run_dir / "datasets"
    manifest_dir = run_dir / "manifests"
    batch_dir = run_dir / "batches"
    rejected_dir = run_dir / "rejected"
    retry_dir = run_dir / "retries"
    provider_dir = run_dir / "provider_internal"
    tmp_dir = run_dir / "tmp"
    for path in [dataset_dir, manifest_dir, batch_dir, rejected_dir, retry_dir, provider_dir, tmp_dir]:
        path.mkdir(parents=True)
    public_rows = []
    for index in range(4):
        row = _distillation_row(f"distill-{index}")
        row["prompt"] = f"Answer with only the integer result: {index} + {4 - index}."
        public_rows.append(row)
    (dataset_dir / "arithmetic.jsonl").write_text(
        "".join(json.dumps(row) + "\n" for row in public_rows),
        encoding="utf-8",
    )
    (batch_dir / "arithmetic.batch000001.jsonl").write_text(
        json.dumps(_distillation_row("distill-batch")) + "\n", encoding="utf-8"
    )
    (rejected_dir / "bad.jsonl").write_text(json.dumps(_distillation_row("distill-rejected")) + "\n", encoding="utf-8")
    (retry_dir / "retry.jsonl").write_text(json.dumps(_distillation_row("distill-retry")) + "\n", encoding="utf-8")
    (provider_dir / "payload.jsonl").write_text(json.dumps(_distillation_row("distill-provider")) + "\n", encoding="utf-8")
    (tmp_dir / "tmp.jsonl").write_text(json.dumps(_distillation_row("distill-tmp")) + "\n", encoding="utf-8")
    (run_dir / "README.md").write_text("# Distillation dataset\n", encoding="utf-8")
    (run_dir / "coverage.json").write_text("{}", encoding="utf-8")
    (manifest_dir / "run.manifest.json").write_text(json.dumps({"datasets": []}), encoding="utf-8")
    (manifest_dir / "arithmetic.run.manifest.json").write_text(json.dumps({"signal": "arithmetic"}), encoding="utf-8")
    (manifest_dir / "arithmetic.batch000001.run.manifest.json").write_text(
        json.dumps({"signal": "arithmetic", "batch_number": 1}), encoding="utf-8"
    )

    calls = []

    class FakeApi:
        def __init__(self, token):
            calls.append(("api", token))

        def list_repo_files(self, **kwargs):
            calls.append(("list", kwargs["repo_id"]))
            return ["coverage.json", "manifests/old.manifest.json", "README.md"]

        def create_commit(self, **kwargs):
            calls.append(("commit", kwargs["repo_id"], [operation.path_in_repo for operation in kwargs["operations"]]))

    monkeypatch.setenv("HF_TOKEN", "token")
    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.HfApi", FakeApi)
    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.create_repo", lambda **kwargs: calls.append(("repo", kwargs)))

    result = push_distillation_run(dataset_dir=dataset_dir, run_dir=run_dir, repo_id="org/distill")

    assert result == {"repo_id": "org/distill", "files": ["data/arithmetic.jsonl"], "rows": 4}
    commit_calls = [call for call in calls if call[0] == "commit"]
    assert len(commit_calls) == 1
    paths = commit_calls[0][2]
    assert "data/arithmetic.jsonl" in paths
    assert "README.md" in paths
    assert "artifacts/coverage.json" in paths
    assert "artifacts/manifests/run.manifest.json" in paths
    assert "coverage.json" in paths
    assert "manifests/old.manifest.json" in paths


@pytest.mark.parametrize(
    ("missing_path", "message"),
    [
        ("README.md", "README.md"),
        ("coverage.json", "coverage.json"),
        ("manifests/run.manifest.json", "run.manifest.json"),
    ],
)
def test_push_distillation_run_requires_public_surface_files(tmp_path, monkeypatch, missing_path, message):
    run_dir = tmp_path / "run"
    dataset_dir = run_dir / "datasets"
    manifest_dir = run_dir / "manifests"
    dataset_dir.mkdir(parents=True)
    manifest_dir.mkdir()
    (dataset_dir / "arithmetic.jsonl").write_text(json.dumps(_distillation_row()) + "\n", encoding="utf-8")
    (run_dir / "README.md").write_text("# Distillation dataset\n", encoding="utf-8")
    (run_dir / "coverage.json").write_text("{}", encoding="utf-8")
    (manifest_dir / "run.manifest.json").write_text(json.dumps({"datasets": []}), encoding="utf-8")
    (run_dir / missing_path).unlink()

    class FakeApi:
        def __init__(self, token):
            pass

        def list_repo_files(self, **kwargs):
            return []

        def create_commit(self, **kwargs):
            pass

    monkeypatch.setenv("HF_TOKEN", "token")
    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.HfApi", FakeApi)
    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.create_repo", lambda **kwargs: None)

    with pytest.raises(FileNotFoundError, match=message):
        push_distillation_run(dataset_dir=dataset_dir, run_dir=run_dir, repo_id="org/distill")

def test_require_publish_prompt_uniqueness_rejects_low_diversity(tmp_path):
    dataset = tmp_path / "distill.jsonl"
    rows = [_distillation_row(f"distill-{index}") for index in range(10)]
    dataset.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    with pytest.raises(ValueError, match="prompt uniqueness gate failed"):
        require_publish_prompt_uniqueness([dataset], min_unique_prompts=0, min_unique_ratio=0.75)


def test_require_publish_prompt_uniqueness_accepts_diverse_prompts(tmp_path):
    dataset = tmp_path / "distill.jsonl"
    rows = []
    for index in range(10):
        row = _distillation_row(f"distill-{index}")
        row["prompt"] = f"Unique prompt {index}"
        rows.append(row)
    dataset.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    summary = require_publish_prompt_uniqueness([dataset], min_unique_prompts=0, min_unique_ratio=0.75)

    assert summary["row_count"] == 10
    assert summary["unique_prompt_count"] == 10
    assert summary["duplicate_prompt_count"] == 0


def test_response_cluster_review_requires_review_for_repeated_cloud_response(tmp_path):
    dataset = tmp_path / "cloud.jsonl"
    rows = []
    for index in range(3):
        row = _distillation_row(f"cloud-{index:06d}")
        row["prompt"] = f"Explain distinct cloud concept {index}."
        row["response"] = "Use autoscaling to adjust capacity as demand changes."
        row["metadata"]["category"] = "general_instruction_following"
        row["metadata"]["template_family"] = "cloud_explanation"
        row["metadata"]["eval_family"] = None
        rows.append(row)
    dataset.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    summary = build_response_cluster_review_summary([dataset])

    assert summary["unresolved_cluster_count"] == 1
    assert summary["clusters"][0]["audit_status"] == "review_required"
    assert summary["clusters"][0]["adjudication"] is None
    with pytest.raises(ValueError, match="unresolved repeated-response cluster"):
        require_publish_resolved_response_clusters([dataset])


def test_response_cluster_review_clears_only_verified_arithmetic_cluster(tmp_path):
    dataset = tmp_path / "arithmetic.jsonl"
    rows = []
    for index in range(3):
        row = _distillation_row(f"arithmetic-{index:06d}")
        row["prompt"] = f"Answer with only the integer result: {index} + {4 - index}."
        rows.append(row)
    dataset.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    summary = require_publish_resolved_response_clusters([dataset])

    assert summary["automatically_cleared_cluster_count"] == 1
    assert summary["unresolved_cluster_count"] == 0
    assert summary["clusters"][0]["audit_status"] == "cleared"
    assert summary["clusters"][0]["adjudication"] == "machine_verified"


def test_push_blocks_unresolved_cluster_before_remote_calls(tmp_path, monkeypatch):
    dataset_dir = tmp_path / "datasets"
    dataset_dir.mkdir()
    dataset = dataset_dir / "cloud.jsonl"
    rows = []
    for index in range(3):
        row = _distillation_row(f"cloud-{index:06d}")
        row["prompt"] = f"Explain distinct cloud concept {index}."
        row["response"] = "Use autoscaling to adjust capacity as demand changes."
        row["metadata"]["category"] = "general_instruction_following"
        row["metadata"]["template_family"] = "cloud_explanation"
        row["metadata"]["eval_family"] = None
        rows.append(row)
    dataset.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    def fail_remote_call(*args, **kwargs):
        pytest.fail("remote setup must not run before the local cluster gate")

    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.get_hf_token", fail_remote_call)
    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.HfApi", fail_remote_call)
    monkeypatch.setattr("slm_synth.distillation_sft.push_hf.create_repo", fail_remote_call)

    with pytest.raises(ValueError, match="unresolved repeated-response cluster"):
        push_distillation_run(dataset_dir=dataset_dir, repo_id="org/distill")


def test_manifest_count_gate_blocks_quarantined_underfill(tmp_path):
    dataset = tmp_path / "cloud.jsonl"
    rows = []
    for index in range(2):
        row = _distillation_row(f"cloud-{index:06d}")
        row["prompt"] = f"Unique cloud prompt {index}."
        rows.append(row)
    dataset.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    manifest = tmp_path / "run.manifest.json"
    manifest.write_text(
        json.dumps(
            {
                "datasets": [
                    {
                        "signal": "cloud",
                        "dataset_path": str(dataset),
                        "manifest_path": "cloud.manifest.json",
                        "row_count": 3,
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="rebuild manifests before publishing"):
        require_manifest_dataset_counts(manifest, [dataset])
