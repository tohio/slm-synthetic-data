import json
from pathlib import Path

import pytest

from slm_synth.distillation_dpo.card import write_dataset_card
from slm_synth.distillation_dpo.acceptance import build_dataset_acceptance_report
from slm_synth.distillation_dpo.io import read_jsonl
from slm_synth.distillation_dpo.push_hf import (
    count_and_validate_jsonl,
    discover_jsonl_files,
    normalize_repo_id,
    push_distillation_dpo_run,
    repo_id_for_family,
)
from slm_synth.distillation_dpo.report import build_coverage_report
from slm_synth.distillation_dpo.pair_quality import filter_pairs_by_quality
from slm_synth.distillation_dpo.schema import validate_distillation_dpo_row
from slm_synth.taxonomy.holdouts import HoldoutRegistry


def _row(row_id="distillation-dpo-1"):
    return {
        "id": row_id,
        "prompt": [{"role": "user", "content": "What is 2 + 2?"}],
        "chosen": [{"role": "assistant", "content": "4"}],
        "rejected": [{"role": "assistant", "content": "5"}],
        "metadata": {
            "category": "direct_arithmetic",
            "difficulty": 1,
            "template_family": "distillation_dpo_teacher_preference",
            "eval_family": "basic_arithmetic_qa",
            "failure_mode": "wrong_numeric_answer",
        },
    }


def test_distillation_dpo_schema_keeps_lineage_out_of_rows():
    row = _row()
    row["teacher_model"] = "deepseek/deepseek-v4-flash"
    with pytest.raises(ValueError, match="forbidden field"):
        validate_distillation_dpo_row(row)


def test_distillation_dpo_pair_quality_rejects_bad_pairs():
    identical = _row("identical")
    identical["rejected"] = list(identical["chosen"])
    prompt_copy = _row("prompt-copy")
    prompt_copy["chosen"] = [{"role": "assistant", "content": "What is 2 + 2?"}]

    accepted, summary = filter_pairs_by_quality(
        family="teacher_response_preference",
        rows=[_row("good"), identical, prompt_copy],
    )

    assert [row["id"] for row in accepted] == ["good"]
    assert summary.accepted_pairs == 1
    assert summary.rejected_pairs == 2


def test_distillation_dpo_report_and_card_from_pipeline_shaped_artifact(tmp_path):
    dataset_dir = tmp_path / "datasets"
    manifest_dir = tmp_path / "manifests"
    dataset_dir.mkdir()
    manifest_dir.mkdir()
    dataset_path = dataset_dir / "teacher_response_preference.jsonl"
    dataset_path.write_text(json.dumps(_row()) + "\n", encoding="utf-8")

    acceptance = build_dataset_acceptance_report([_row()])
    manifest_path = manifest_dir / "distillation-dpo-smoke-001.manifest.json"
    manifest_path.write_text(
        json.dumps({
            "dataset_type": "distillation-dpo",
            "generation_run": "distillation-dpo-smoke-001",
            "teacher_model": "deepseek/deepseek-v4-flash",
            "teacher_provider": "openrouter",
            "chosen_source": "teacher",
            "rejected_source": "controlled_weak",
            "target_consumer": "slm-distillation",
            "datasets": [{
                "family": "teacher_response_preference",
                "dataset_path": str(dataset_path),
                "row_count": 1,
            }],
            "total_rows": 1,
            "metadata": {
                "dataset_acceptance": acceptance,
                "target_pairs": 1,
            },
        }),
        encoding="utf-8",
    )

    report = build_coverage_report([dataset_dir], holdout_registry=HoldoutRegistry([]))
    assert report["dataset_type"] == "distillation-dpo"
    assert report["row_count"] == 1
    assert report["dataset_acceptance"]["publish_ready"] is True

    card_path = write_dataset_card(
        run_manifest_path=manifest_path,
        output_path=tmp_path / "README.md",
        dataset_name="SLM Synthetic Distillation DPO",
    )
    assert "Distillation-DPO" in card_path.read_text()


def test_distillation_dpo_push_discovers_public_files_only(tmp_path):
    dataset_dir = tmp_path / "datasets"
    dataset_dir.mkdir()
    public_path = dataset_dir / "teacher_response_preference.jsonl"
    batch_path = dataset_dir / "teacher_response_preference.batch000001.jsonl"
    scratch_path = dataset_dir / "scratch" / "teacher_response_preference.jsonl"
    public_path.write_text(json.dumps(_row("public")) + "\n", encoding="utf-8")
    batch_path.write_text(json.dumps(_row("batch")) + "\n", encoding="utf-8")
    scratch_path.parent.mkdir()
    scratch_path.write_text(json.dumps(_row("scratch")) + "\n", encoding="utf-8")

    assert discover_jsonl_files(dataset_dir) == [public_path]
    assert count_and_validate_jsonl(public_path) == 1
    assert repo_id_for_family(
        repo_owner="tohio",
        repo_prefix="slm-synthetic-distillation-dpo",
        family="teacher_response_preference",
    ) == "tohio/slm-synthetic-distillation-dpo-teacher-response-preference"
    assert normalize_repo_id("/tohio/slm-synthetic-distillation-dpo/") == "tohio/slm-synthetic-distillation-dpo"


def test_push_distillation_dpo_run_uploads_exact_repo_id(tmp_path, monkeypatch):
    run_dir = tmp_path / "run"
    dataset_dir = run_dir / "datasets"
    manifest_dir = run_dir / "manifests"
    dataset_dir.mkdir(parents=True)
    manifest_dir.mkdir()
    (dataset_dir / "teacher_response_preference.jsonl").write_text(json.dumps(_row()) + "\n", encoding="utf-8")
    (run_dir / "README.md").write_text("# Distillation DPO\n", encoding="utf-8")
    coverage = build_coverage_report([dataset_dir], holdout_registry=HoldoutRegistry([]))
    (run_dir / "coverage.json").write_text(json.dumps(coverage), encoding="utf-8")
    acceptance = build_dataset_acceptance_report([_row()])
    (manifest_dir / "distillation-dpo-smoke-001.manifest.json").write_text(
        json.dumps({"metadata": {"dataset_acceptance": acceptance}}),
        encoding="utf-8",
    )

    calls = []

    class FakeApi:
        def __init__(self, token):
            calls.append(("api", token))
        def list_repo_files(self, **kwargs):
            return ["coverage.json", "manifests/old.manifest.json", "README.md"]
        def create_commit(self, **kwargs):
            calls.append(("commit", kwargs["repo_id"], [op.path_in_repo for op in kwargs["operations"]]))

    monkeypatch.setenv("HF_TOKEN", "token")
    monkeypatch.setattr("slm_synth.distillation_dpo.push_hf.HfApi", FakeApi)
    monkeypatch.setattr("slm_synth.distillation_dpo.push_hf.create_repo", lambda **kwargs: calls.append(("repo", kwargs)))

    result = push_distillation_dpo_run(
        dataset_dir=dataset_dir,
        run_dir=run_dir,
        repo_id="tohio/slm-synthetic-distillation-dpo",
    )
    assert result["repo_count"] == 1
    assert result["rows"] == 1


def test_distillation_dpo_make_targets_use_pipeline():
    makefile = Path("Makefile").read_text()
    block = makefile.split("distillation-dpo-smoke:", 1)[1].split("sft-smoke:", 1)[0]
    assert "slm_synth.distillation_dpo.pipeline" in block
    assert "generate-llm-run" not in block
    assert "$(OPENROUTER_ENV)" in block
    assert "slm_synth.dpo" not in block


def test_distillation_dpo_push_target_uses_exact_repo_id():
    makefile = Path("Makefile").read_text()
    block = makefile.split("distillation-dpo-push:", 1)[1].split("sft-smoke:", 1)[0]
    assert "DISTILLATION_DPO_HF_REPO ?= $(HF_NAMESPACE)/slm-synthetic-distillation-dpo" in makefile
    assert "--repo-id $(DISTILLATION_DPO_HF_REPO)" in block
