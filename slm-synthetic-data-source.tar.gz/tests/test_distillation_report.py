import json

import pytest

from slm_synth.distillation_sft.report import build_coverage_report, write_coverage_report


def _row(row_id, *, template_family):
    return {
        "id": row_id,
        "prompt": "Explain the requested database or cloud behavior.",
        "reasoning": None,
        "response": "A concise validated response.",
        "metadata": {
            "category": "general_instruction_following",
            "difficulty": 2,
            "template_family": template_family,
            "eval_family": None,
        },
    }


def _write_run_manifest(path, datasets):
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "generation_run": "smoke-001",
                "teacher_model": "openai/gpt-4.1-mini",
                "teacher_provider": "openrouter",
                "datasets": datasets,
                "total_rows": sum(dataset["row_count"] for dataset in datasets),
                "metadata": {
                    "candidate_rows": 5,
                    "planned_prompt_rows": 5,
                    "accepted_rows": 5,
                    "rejected_rows": 0,
                    "candidate_rows_per_signal": {"cloud": 2, "database": 3},
                },
            },
            default=str,
        ),
        encoding="utf-8",
    )


def test_build_distillation_coverage_report_from_run_manifest(tmp_path):
    run_manifest = tmp_path / "smoke-001.manifest.json"
    dataset_dir = tmp_path / "datasets"
    dataset_dir.mkdir()
    (dataset_dir / "cloud.jsonl").write_text(
        "".join(json.dumps(_row(f"cloud-{index}", template_family="cloud_architecture_explanation")) + "\n" for index in range(2)),
        encoding="utf-8",
    )
    (dataset_dir / "database.jsonl").write_text(
        "".join(json.dumps(_row(f"database-{index}", template_family="sql_grouping_query")) + "\n" for index in range(3)),
        encoding="utf-8",
    )
    _write_run_manifest(
        run_manifest,
        [
            {
                "signal": "cloud",
                "dataset_path": tmp_path / "datasets" / "cloud.jsonl",
                "manifest_path": tmp_path / "manifests" / "cloud.smoke-001.manifest.json",
                "row_count": 2,
            },
            {
                "signal": "database",
                "dataset_path": tmp_path / "datasets" / "database.jsonl",
                "manifest_path": tmp_path / "manifests" / "database.smoke-001.manifest.json",
                "row_count": 3,
            },
        ],
    )

    report = build_coverage_report(run_manifest)

    assert report["dataset_type"] == "distillation"
    assert report["generation_run"] == "smoke-001"
    assert report["teacher_provider"] == "openrouter"
    assert report["teacher_model"] == "openai/gpt-4.1-mini"
    assert report["candidate_rows"] == 5
    assert report["planned_prompt_rows"] == 5
    assert report["accepted_rows"] == 5
    assert report["rejected_rows"] == 0
    assert report["row_count"] == 5
    assert report["signals"] == {"cloud": 2, "database": 3}
    assert report["candidate_rows_per_signal"] == {"cloud": 2, "database": 3}
    assert report["categories"] == {"general_instruction_following": 5}
    assert report["eval_families"] == {"null": 5}
    assert report["template_families"] == {
        "cloud_architecture_explanation": 2,
        "sql_grouping_query": 3,
    }
    assert report["difficulty_counts"] == {"2": 5}
    assert report["response_diversity"]["row_count"] == 5
    assert report["response_diversity"]["unique_response_count"] == 1
    assert report["response_diversity"]["duplicate_response_count"] == 4
    assert report["response_diversity"]["signals"]["cloud"]["unique_response_ratio"] == 0.5
    assert report["response_diversity"]["signals"]["database"]["unique_response_ratio"] == pytest.approx(1 / 3)
    assert report["dataset_paths"]["cloud"] == str(tmp_path / "datasets" / "cloud.jsonl")
    assert report["manifest_paths"]["database"] == str(tmp_path / "manifests" / "database.smoke-001.manifest.json")


def test_write_distillation_coverage_report_writes_json(tmp_path):
    output = tmp_path / "coverage.json"
    report = {
        "dataset_type": "distillation",
        "generation_run": "smoke-001",
        "teacher_model": "openai/gpt-4.1-mini",
        "teacher_provider": "openrouter",
        "candidate_rows": None,
        "planned_prompt_rows": None,
        "accepted_rows": 0,
        "rejected_rows": None,
        "row_count": 0,
        "signals": {},
        "candidate_rows_per_signal": {},
        "dataset_paths": {},
        "manifest_paths": {},
    }

    path = write_coverage_report(report=report, path=output)

    assert path == output
    assert json.loads(output.read_text(encoding="utf-8")) == report


def test_build_distillation_coverage_report_rejects_duplicate_signals(tmp_path):
    run_manifest = tmp_path / "smoke-001.manifest.json"
    _write_run_manifest(
        run_manifest,
        [
            {"signal": "cloud", "dataset_path": "cloud-a.jsonl", "manifest_path": "cloud-a.json", "row_count": 1},
            {"signal": "cloud", "dataset_path": "cloud-b.jsonl", "manifest_path": "cloud-b.json", "row_count": 1},
        ],
    )

    with pytest.raises(ValueError, match="duplicate signal"):
        build_coverage_report(run_manifest)
