import json

import pytest

from slm_synth.pretrain.dedup import (
    PUBLIC_FILENAME,
    audit_public_records,
    consolidate_and_deduplicate,
)


def _consolidate(tmp_path):
    return consolidate_and_deduplicate(
        validated_dir=tmp_path / "validated",
        deduped_dir=tmp_path / "deduped",
        rejected_dir=tmp_path / "rejected",
        manifest_dir=tmp_path / "manifests",
    )


def test_exact_dedup_general_mcq(tmp_path):
    validated = tmp_path / "validated"
    validated.mkdir()
    record = {
        "type": "educational_qa_mcq_general",
        "question": "Which word is an adverb in 'Mina quickly packed the box'?",
        "evidence": "Mina quickly packed the box.",
        "choices": ["Mina", "quickly", "packed", "box"],
        "correct_index": 1,
        "explanation": "Quickly describes the action.",
    }
    path = validated / "educational_qa_mcq_general.jsonl"
    with path.open("w") as handle:
        handle.write(json.dumps(record) + "\n")
        handle.write(json.dumps(record) + "\n")

    report = _consolidate(tmp_path)
    rows = [json.loads(line) for line in (tmp_path / "deduped" / PUBLIC_FILENAME).read_text().splitlines()]

    assert report["accepted_rows"] == 1
    assert report["exact_duplicate_rows"] == 1
    assert rows[0]["metadata"] == {"signal": "educational_qa_mcq_general"}
    assert set(rows[0]) == {"id", "text", "metadata"}


def test_math_mcq_dedup_ignores_choice_permutations_for_same_question_and_answer(tmp_path):
    validated = tmp_path / "validated"
    validated.mkdir()
    rows = [
        {
            "type": "educational_qa_mcq_math",
            "question": "Start with 72, remove 42, then remove 10. How many remain?",
            "choices": ["20", "18", "16", "22"],
            "correct_index": 0,
            "explanation": "72 - 42 = 30, then 30 - 10 = 20.",
        },
        {
            "type": "educational_qa_mcq_math",
            "question": "Start with 72, remove 42, then remove 10. How many remain?",
            "choices": ["18", "20", "16", "22"],
            "correct_index": 1,
            "explanation": "72 - 42 = 30, then 30 - 10 = 20.",
        },
    ]
    path = validated / "educational_qa_mcq_math.jsonl"
    with path.open("w") as handle:
        for row in rows:
            handle.write(json.dumps(row) + "\n")

    report = _consolidate(tmp_path)

    assert report["accepted_rows"] == 1
    assert report["near_duplicate_rows"] == 1


def test_public_audit_rejects_cross_signal_exact_duplicates():
    rows = [
        {
            "id": "one",
            "text": "A long grounded explanation uses the same stable structure and facts here.",
            "metadata": {"signal": "arithmetic"},
        },
        {
            "id": "two",
            "text": "A long grounded explanation uses the same stable structure and facts here.",
            "metadata": {"signal": "task_code"},
        },
    ]

    with pytest.raises(ValueError, match="exact duplicate"):
        audit_public_records(rows)


def test_public_audit_normalizes_python_identifiers():
    rows = [
        {
            "id": "one",
            "text": "Task: Add values.\nPlan:\n1. Iterate.\nCode:\n```python\ndef sum_values(items):\n    return sum(items)\n```",
            "metadata": {"signal": "task_code"},
        },
        {
            "id": "two",
            "text": "Task: Add values.\nPlan:\n1. Iterate.\nCode:\n```python\ndef total_numbers(values):\n    return sum(values)\n```",
            "metadata": {"signal": "task_code"},
        },
    ]

    with pytest.raises(ValueError, match="near-duplicate"):
        audit_public_records(rows)


def test_math_mcq_questions_remain_local_and_teacher_only_explains():
    from slm_synth.pretrain.artifacts import EducationalQAMCQMathArtifactFactory
    from slm_synth.pretrain.grounded import GroundedSignalGenerator

    class NoopLLM:
        pass

    factory = EducationalQAMCQMathArtifactFactory()
    artifacts = [factory.build(index) for index in range(factory.UNIQUE_CANDIDATE_CAPACITY)]
    assert len({artifact.payload["question"] for artifact in artifacts}) == len(artifacts)

    prompt = GroundedSignalGenerator(
        "educational_qa_mcq_math", NoopLLM(), batch_size=len(artifacts), factory=factory
    ).build_prompt(artifacts)
    schema = GroundedSignalGenerator(
        "educational_qa_mcq_math", NoopLLM(), batch_size=len(artifacts), factory=factory
    ).response_schema(len(artifacts))
    assert "Question, choices, and verified answer remain local" in prompt
    assert schema["properties"]["records"]["items"]["required"] == ["artifact_id", "explanation"]
