"""Shared adaptive batch-size control for live generation workflows."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class AdaptiveBatchSizeController:
    """AIMD-style controller for rows requested per provider call."""

    maximum: int
    minimum: int = 1
    initial: int = 4
    increase_successes: int = 16
    decrease_factor: float = 0.5

    def __post_init__(self) -> None:
        self.maximum = max(1, int(self.maximum))
        self.minimum = min(self.maximum, max(1, int(self.minimum)))
        self.initial = min(self.maximum, max(self.minimum, int(self.initial)))
        self.increase_successes = max(1, int(self.increase_successes))
        self.decrease_factor = min(1.0, max(0.01, float(self.decrease_factor)))
        self.current = self.initial
        self.observed_minimum = self.current
        self.observed_peak = self.current
        self.increases = 0
        self.decreases = 0
        self.failures = 0
        self.successes = 0
        self._successes_since_change = 0

    def record_success(self) -> None:
        self.successes += 1
        self._successes_since_change += 1
        if self.current >= self.maximum or self._successes_since_change < self.increase_successes:
            return

        previous = self.current
        self.current = min(self.maximum, self.current * 2)
        self.observed_peak = max(self.observed_peak, self.current)
        self._successes_since_change = 0
        if self.current != previous:
            self.increases += 1

    def record_failure(self) -> None:
        self.failures += 1
        previous = self.current
        reduced = max(self.minimum, int(previous * self.decrease_factor))
        if reduced >= previous and previous > self.minimum:
            reduced = previous - 1
        self.current = reduced
        self.observed_minimum = min(self.observed_minimum, self.current)
        self._successes_since_change = 0
        if self.current != previous:
            self.decreases += 1

    def snapshot(self) -> dict[str, int]:
        return {
            "adaptive_batch_size_current": self.current,
            "adaptive_batch_size_maximum": self.maximum,
            "adaptive_batch_size_minimum": self.minimum,
            "adaptive_batch_size_observed_minimum": self.observed_minimum,
            "adaptive_batch_size_observed_peak": self.observed_peak,
            "adaptive_batch_size_increases": self.increases,
            "adaptive_batch_size_decreases": self.decreases,
            "adaptive_batch_size_successes": self.successes,
            "adaptive_batch_size_failures": self.failures,
        }


def aggregate_adaptive_batch_size_controllers(
    controllers: list[AdaptiveBatchSizeController],
) -> dict[str, int]:
    """Aggregate independent per-group controllers into run-level telemetry."""
    if not controllers:
        return {
            "adaptive_batch_size_current": 0,
            "adaptive_batch_size_maximum": 0,
            "adaptive_batch_size_minimum": 0,
            "adaptive_batch_size_observed_minimum": 0,
            "adaptive_batch_size_observed_peak": 0,
            "adaptive_batch_size_increases": 0,
            "adaptive_batch_size_decreases": 0,
            "adaptive_batch_size_successes": 0,
            "adaptive_batch_size_failures": 0,
        }
    return {
        "adaptive_batch_size_current": controllers[-1].current,
        "adaptive_batch_size_maximum": max(item.maximum for item in controllers),
        "adaptive_batch_size_minimum": min(item.minimum for item in controllers),
        "adaptive_batch_size_observed_minimum": min(
            item.observed_minimum for item in controllers
        ),
        "adaptive_batch_size_observed_peak": max(
            item.observed_peak for item in controllers
        ),
        "adaptive_batch_size_increases": sum(item.increases for item in controllers),
        "adaptive_batch_size_decreases": sum(item.decreases for item in controllers),
        "adaptive_batch_size_successes": sum(item.successes for item in controllers),
        "adaptive_batch_size_failures": sum(item.failures for item in controllers),
    }
