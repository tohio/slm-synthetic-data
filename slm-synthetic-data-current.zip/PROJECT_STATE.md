# Project State

Internal handoff file. Keep this file local; do not publish it to GitHub.

`slm-synthetic-data` generates and publishes synthetic datasets for the SLM stack. The repo owns data creation, validation, manifests, coverage reports, dataset cards, and Hugging Face publishing.

## Scope

In scope:

- Pretraining synthetic data.
- Generic SFT datasets.
- Generic DPO preference datasets.
- Response-distillation teacher datasets for `slm-distillation`.
- Distillation DPO preference datasets for `slm-distillation`.

Out of scope:

- Model training.
- Evaluation gates for trained models.
- Checkpoint naming.
- Model export policy.
- Logits artifacts. Logits are derived by `slm-distillation`.

## Current Architecture

| Area | Package | Public Rows |
|---|---|---|
| Pretraining | `slm_synth/pretrain/` | Grounded text artifacts under `data/runs/<run>/deduped` |
| SFT | `slm_synth/sft/` | `{"id": "string", "messages": [...], "metadata": {...}}` |
| DPO | `slm_synth/dpo/` | `{"id": "string", "prompt": [...], "chosen": [...], "rejected": [...], "metadata": {...}}` |
| Distillation SFT | `slm_synth/distillation_sft/` | `{"id": "string", "prompt": "string", "reasoning": null, "response": "string"}` |
| Distillation DPO | `slm_synth/distillation_dpo/` | `{"id": "string", "prompt": [...], "chosen": [...], "rejected": [...], "metadata": {...}}` |

OpenRouter is the supported live provider surface. Shared provider calls, retry behavior, adaptive request admission, routing policy, and structured-output handling live in `slm_synth/llm.py`. Adaptive batch sizing lives in `slm_synth/adaptive_batch.py`.

## Artifact Names

```text
sft-*                generic SFT datasets
dpo-*                generic DPO datasets
distillation-sft-*   teacher response datasets for distillation
distillation-dpo-*   DPO pairs for distilled model alignment
```

`distillation-dpo-*` is separate from generic `dpo-*` and carries lineage metadata for `slm-distillation`.

## Production Planning Defaults

| Surface | Target knob | Default |
|---|---|---:|
| Pretraining | `PRETRAIN_TARGET_TOKENS` | `1000000` |
| SFT | `SFT_TARGET_ROWS` | `14000` |
| DPO | `DPO_TARGET_PAIRS` | `14000` |
| Distillation SFT | `DISTILLATION_SFT_TARGET_ROWS` | `100000` |
| Distillation DPO | `DISTILLATION_DPO_TARGET_PAIRS` | `50000` |

SFT/DPO keep `SFT_COUNT_PER_FAMILY` and `DPO_COUNT_PER_FAMILY` as explicit lower-level overrides.

## Run Ladder

Next execution work should follow this order:

1. Smoke runs for active artifact families.
2. Validation checks over public rows, manifests, telemetry, coverage, and public-directory hygiene.
3. Small-scale target overrides.
4. Full production runs after earlier outputs pass inspection.

New TODO items should come from observed failures or quality gaps in smoke, validation, small-scale, or production results.

## Current Priority

Keep the repo clean and synchronized while preparing for the run ladder. Public docs use the root README for overview, `docs/` for project-level reference, and package READMEs for code-folder orientation. Do not add training, eval, checkpoint, export, or logits policy to this repo.
