# TODO

Internal handoff file. Keep this file local; do not publish it to GitHub.

Maintainer checklist for the next implementation pass.

## P0 - Distillation HF Artifacts

- [x] Add `distillation-sft-*` as the primary response-distillation artifact family.
- [x] Add `distillation-dpo-*` as a dedicated preference artifact family for `slm-distillation`.
- [x] Replace primary `distill-*` Make targets with:
  - `make distillation-sft-smoke`
  - `make distillation-sft-generate`
  - `make distillation-sft-report`
  - `make distillation-sft-inspect`
  - `make distillation-sft-push`
- [x] Rename response-distillation Make variables from `DISTILL_*` to `DISTILLATION_SFT_*`.
- [x] Add matching distillation DPO targets:
  - `make distillation-dpo-smoke`
  - `make distillation-dpo-generate`
  - `make distillation-dpo-report`
  - `make distillation-dpo-inspect`
  - `make distillation-dpo-push`
- [x] Remove `distill-*` targets without compatibility aliases.
- [x] Standardize public distillation SFT rows to:

```json
{"id": "string", "prompt": "string", "reasoning": null, "response": "string"}
```

- [x] Fix any code, tests, or docs that still allow response-distillation reasoning lists.
- [x] Add `distillation-dpo` manifest metadata:

```yaml
dataset_type: distillation-dpo
chosen_source: teacher
rejected_source: controlled_weak
teacher_model: deepseek/deepseek-v4-flash
target_consumer: slm-distillation
```

## P0 - Distillation Production Data Quality

- [x] Treat built-in distillation seed prompts as smoke-only.
- [x] Add production prompt-spec generation for distillation SFT.
- [x] Add duplicate and near-duplicate prompt checks before teacher calls.
- [x] Add accepted-row planning, including `DISTILLATION_SFT_TARGET_ROWS=100000`.
- [x] Stop relying on token presets for production distillation datasets.
- [x] Add lightweight response gates:
  - [x] Reject empty or too-short responses.
  - [x] Reject responses that repeat the prompt.
  - [x] Reject malformed JSON or schema leakage.
  - [x] Reject unexpected refusals outside factual-restraint cases.
  - [x] Add cheap category checks where the signal supports them.

- [x] Define production source contract for `distillation-dpo-*`.
- [x] Keep `distillation-dpo-*` production data isolated from generic `dpo-*`.
- [x] Use teacher-quality chosen responses and controlled-weak rejected responses for `distillation-dpo-*` production runs.
- [x] Keep student-model sampling out of `slm-synthetic-data`; actual student-output DPO belongs in `slm-distillation` if needed later.
- [x] Add target-pair planning, including `DISTILLATION_DPO_TARGET_PAIRS=50000`.
- [x] Add lightweight distillation-DPO pair-quality gates:
  - [x] Reject identical chosen/rejected pairs.
  - [x] Reject non-contrastive pairs.
  - [x] Reject malformed chosen/rejected responses.
  - [x] Reject prompt-copy pairs.
  - [x] Reject schema leakage.

## P0 - Distillation Public Surface

- [x] Keep batch shards, partial files, rejected rows, local retry files, and provider internals out of public dataset directories.
- [x] Keep public distillation SFT artifacts as per-signal JSONL files.
- [x] Do not add distillation-only `train`/`validation`/`test` split files; `slm-distillation` will combine and split downstream.
- [x] Publish only public signal JSONL files, README/dataset card, manifest, and coverage report to Hugging Face.
- [x] Verify HF push discovery contains no scratch files and does not upload duplicate batch files when final public files exist.

## P0 - Archive And Package Hygiene

- [x] Resolve the zero-byte Python files in the archive.
- [x] Delete obsolete migration stubs where replacement code under `slm_synth/pretrain/` is the supported path.
- [x] Restore or remove zero-byte files that were emptied accidentally during zip/sync.
- [x] Rename `prompts/__.init__.py` to `prompts/__init__.py`, or remove `prompts/` if the root prompt package is obsolete.
- [x] Remove committed or archived `__pycache__/` and `.pyc` files from future zips.
- [x] Remove public docs references to internal `TODO.md`.
- [x] Keep `TODO.md` and `PROJECT_STATE.md` local/internal; do not publish them to GitHub.
- [x] Keep `.gitignore` covering both internal handoff files.
- [x] Keep `.gitignore` covering Python cache files and generated data directories.

## P0 - Publish Path Integrity

- [x] Prefer final public JSONL files over matching `.batch*.jsonl` files in Hugging Face discovery for distillation, SFT, and DPO.
- [x] Separate public dataset files from scratch files before upload.
- [x] For distillation, fix the active upload duplicate hazard where merged signal files and `.batch` files currently coexist in the dataset directory.
- [x] For SFT/DPO, prevent stale merged files or stale batch shards from being uploaded together under the same family.
- [x] Add tests that fail if HF push discovers scratch, batch, partial, rejected, retry, or provider-internal files.

## P1 - Run Ladder

- [x] Add explicit production planning knobs for generic SFT/DPO: `SFT_TARGET_ROWS` and `DPO_TARGET_PAIRS`.
- [x] Track rows, retries, adaptive batch failures, cost, request tokens, aggregate request seconds, and production planning fields in run manifests.
- [x] Fix distillation aggregate telemetry so run-level cost, request tokens, retries, and batch counts reflect per-signal totals.
- [x] Expose OpenRouter routing policy with `auto`, `prefer`, and `strict` runtime modes.
- [x] Keep strict provider pinning opt-in only; default live generation uses `OPENROUTER_ROUTING_MODE=auto`.
- [x] Unify adaptive concurrency defaults so plain batch helpers do not silently clamp `adaptive_initial_in_flight` down to `1`.
- [x] Prefer typed OpenAI/OpenRouter exception handling before substring matching for retryable provider errors.
- [x] Rework retry elapsed-time accounting so admission waits and adaptive cooldown waits do not exhaust the provider retry budget.
- Preserve current public row boundaries:
  - SFT rows contain `id`, `messages`, and public `metadata`.
  - DPO rows contain `id`, `prompt`, `chosen`, `rejected`, and public `metadata`.
  - Distillation SFT rows contain `id`, `prompt`, `reasoning: null`, and `response`.
  - Distillation DPO rows contain `id`, `prompt`, `chosen`, `rejected`, and public `metadata`.
  - Teacher/provider/run/cost/retry details stay in manifests.
- Run smoke jobs first for every active artifact family:
  - `make sft-smoke`
  - `make dpo-smoke`
  - `make distillation-sft-smoke`
  - `make distillation-dpo-smoke`
- Run validation checks after smoke jobs:
  - inspect public rows and pairs
  - inspect run manifests for planning and telemetry fields
  - verify public dataset directories exclude batch shards, partial files, rejected rows, retry files, and provider internals
  - run focused pytest for the touched generation and publishing surfaces
- Run small-scale target overrides before full production:
  - `SFT_TARGET_ROWS=<small> make sft-generate`
  - `DPO_TARGET_PAIRS=<small> make dpo-generate`
  - `DISTILLATION_SFT_TARGET_ROWS=<small> make distillation-sft-generate`
  - `DISTILLATION_DPO_TARGET_PAIRS=<small> make distillation-dpo-generate`
- Run full production only after smoke, validation, and small-scale outputs pass inspection.
- Add new TODO items only from observed failures or quality gaps in smoke, validation, small-scale, or production results.

## P2 - Maintenance

- [x] Use `slm_synth/distillation_sft/` as the response-distillation code package so the package matches the `distillation-sft-*` artifact family.
- [x] Remove stale empty top-level `slm_synth/artifacts/` and `slm_synth/sources/` folders from the tracked package layout.
- [x] Add focused sub-READMEs for non-trivial code package folders.
- Defer SFT/DPO copy-paste reduction until run observations show the duplication is blocking maintenance.
- Remove or consolidate the old `slm_synth/rate_limit.py` path only after confirming pretraining uses the shared adaptive request controller consistently.
- Scope pytest warning ignores to specific noisy packages instead of blanket ignoring `DeprecationWarning` and `UserWarning`.
- Remove unused runtime requirements or split dev/test dependencies into a separate requirements file.
- Revisit whether large binary docs assets should remain in the repo after the functional blockers are cleared.

## P2 - Documentation

- [x] Keep root `README.md` high-level and move project-level reference material under `docs/`.
- [x] Document the final artifact naming convention in `docs/DATASET_PURPOSE.md`:
  - `sft-*`: generic SFT datasets
  - `dpo-*`: generic DPO datasets
  - `distillation-sft-*`: teacher response datasets for distillation
  - `distillation-dpo-*`: DPO pairs for distilled model alignment
- [x] Document the run ladder in `docs/COMMANDS.md`: smoke, validation, small-scale target override, full production.
- [x] Remove stale distillation token-target planning guidance from public docs.
- [x] Keep docs concrete and product-style.

## Out Of Scope

- Do not add model training.
- Do not add trained-model eval gates.
- Do not add checkpoint naming policy.
- Do not add model export policy.
- Do not create logits artifacts.
