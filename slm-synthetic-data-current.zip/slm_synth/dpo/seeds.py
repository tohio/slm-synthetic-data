"""Deterministic seed-row builders for synthetic DPO datasets."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from slm_synth.dpo.schema import validate_dpo_row
from slm_synth.taxonomy.holdouts import HoldoutRegistry, load_default_holdout_registry

DPO_SEED_FAMILIES = frozenset(
    {
        "ai_concept_explanation",
        "answer_only_arithmetic",
        "capital_city_qa",
        "code_expression_result",
        "clear_sky_color_qa",
        "code_generation_function",
        "code_explanation_no_code",
        "direct_division",
        "direct_subtraction",
        "function_completion_body_only",
        "list_exact_n_items",
        "private_or_unverifiable_company_fact",
        "repeat_exact_n_times",
    }
)


def build_seed_rows(
    *,
    family: str,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build deterministic DPO seed rows for one supported family."""
    normalized_family = _validate_family(family)
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    if normalized_family == "ai_concept_explanation":
        return build_ai_concept_explanation_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "answer_only_arithmetic":
        return build_answer_only_arithmetic_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "capital_city_qa":
        return build_capital_city_qa_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "clear_sky_color_qa":
        return build_clear_sky_color_qa_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "code_expression_result":
        return build_code_expression_result_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "direct_subtraction":
        return build_direct_subtraction_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "direct_division":
        return build_direct_division_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "repeat_exact_n_times":
        return build_repeat_exact_n_times_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "list_exact_n_items":
        return build_list_exact_n_items_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "code_generation_function":
        return build_code_generation_function_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "code_explanation_no_code":
        return build_code_explanation_no_code_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "function_completion_body_only":
        return build_function_completion_body_only_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    if normalized_family == "private_or_unverifiable_company_fact":
        return build_private_or_unverifiable_company_fact_rows(
            count=count,
            start_index=start_index,
            holdout_registry=registry,
        )
    raise AssertionError(f"unhandled DPO seed family: {normalized_family}")


def build_ai_concept_explanation_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build AI concept explanation DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _ai_concept_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_ai_concept_explanation_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "general_instruction_following",
                "failure_mode": "wrong_factual_answer",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} AI concept DPO rows")


def build_answer_only_arithmetic_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build answer-only arithmetic DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _arithmetic_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        answer = str(candidate["answer"])
        row = {
            "id": f"dpo_answer_only_arithmetic_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": answer},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "answer_only_compliance",
                "failure_mode": "extra_explanation",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} answer-only arithmetic DPO rows")


def _ai_concept_candidates() -> Iterable[dict[str, Any]]:
    concepts = (
        {
            "concept": "attention_mechanism",
            "prompt": "In machine learning, what is an attention mechanism?",
            "answer": "It helps a model focus on the most relevant parts of the input when producing an output.",
            "rejected": "It is the electrical power unit inside a computer that converts voltage for AI hardware.",
            "difficulty": 1,
        },
        {
            "concept": "embedding_vector",
            "prompt": "What is an embedding vector in machine learning?",
            "answer": "It is a numeric representation of data, such as a word or item, that a model can process.",
            "rejected": "It is a network cable that physically connects a computer to a router.",
            "difficulty": 1,
        },
        {
            "concept": "training_loss",
            "prompt": "In AI training, what does loss measure?",
            "answer": "Loss measures how far the model's predictions are from the desired answers.",
            "rejected": "Loss measures how many files were deleted from the training computer.",
            "difficulty": 1,
        },
        {
            "concept": "classification_model",
            "prompt": "What does a classification model do?",
            "answer": "It assigns an input to one of a set of categories or labels.",
            "rejected": "It always writes long paragraphs of text and cannot choose labels.",
            "difficulty": 1,
        },
        {
            "concept": "language_model",
            "prompt": "What is a language model?",
            "answer": "It is a model trained to predict or generate text based on patterns in language.",
            "rejected": "It is a mechanical translator device that works without training on text.",
            "difficulty": 1,
        },
    )

    for concept in concepts:
        yield {
            **concept,
            "template_family": "short_ai_concept_definition",
            "eval_family": "ai_concept_explanation",
            "holdout_key": {
                "type": "ai_concept",
                "concept": concept["concept"],
            },
        }


def build_capital_city_qa_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build capital-city DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _capital_city_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_capital_city_qa_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "concise_factual_qa",
                "failure_mode": "wrong_factual_answer",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} capital-city DPO rows")


def build_clear_sky_color_qa_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build sky-color DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _clear_sky_color_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_clear_sky_color_qa_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "concise_factual_qa",
                "failure_mode": "wrong_factual_answer",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} sky-color DPO rows")


def build_code_expression_result_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build Python expression-result DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _code_expression_result_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_code_expression_result_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "code_expression_evaluation",
                "failure_mode": "code_logic_error",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} code-expression DPO rows")


def build_direct_subtraction_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build direct subtraction DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _direct_subtraction_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        answer = str(candidate["answer"])
        row = {
            "id": f"dpo_direct_subtraction_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": answer},
            ],
            "rejected": [
                {"role": "assistant", "content": str(candidate["rejected"])},
            ],
            "metadata": {
                "category": "direct_arithmetic",
                "failure_mode": "wrong_numeric_answer",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} direct-subtraction DPO rows")


def build_direct_division_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build direct integer-division DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _direct_division_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        answer = str(candidate["answer"])
        row = {
            "id": f"dpo_direct_division_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": answer},
            ],
            "rejected": [
                {"role": "assistant", "content": str(candidate["rejected"])},
            ],
            "metadata": {
                "category": "direct_arithmetic",
                "failure_mode": "wrong_numeric_answer",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} direct-division DPO rows")


def build_repeat_exact_n_times_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build exact-repeat DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _repeat_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_repeat_exact_n_times_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "exact_output_format_control",
                "failure_mode": "format_violation",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} exact-repeat DPO rows")


def build_list_exact_n_items_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build exact-list DPO pairs without using held-out items."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _list_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_list_exact_n_items_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "exact_output_format_control",
                "failure_mode": "format_violation",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} exact-list DPO rows")


def build_private_or_unverifiable_company_fact_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build DPO restraint pairs for private or unverifiable company facts."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _private_company_fact_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_private_or_unverifiable_company_fact_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": candidate["category"],
                "failure_mode": "unknown_fact_fabrication",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} private-company fact DPO rows")


def build_code_generation_function_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build DPO pairs for simple code generation without using held-out tasks."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _code_generation_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_code_generation_function_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "code_generation",
                "failure_mode": "code_includes_explanation",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} code-generation DPO rows")


def build_function_completion_body_only_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build DPO pairs for function-body-only completion tasks."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _function_completion_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_function_completion_body_only_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "code_generation",
                "failure_mode": "code_includes_explanation",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} function-completion DPO rows")


def build_code_explanation_no_code_rows(
    *,
    count: int,
    start_index: int = 1,
    holdout_registry: HoldoutRegistry | None = None,
) -> list[dict[str, Any]]:
    """Build DPO pairs for code explanations that should not repeat code."""
    if not isinstance(count, int) or count < 1:
        raise ValueError("count must be a positive integer")
    if not isinstance(start_index, int) or start_index < 1:
        raise ValueError("start_index must be a positive integer")

    registry = holdout_registry or load_default_holdout_registry()
    rows: list[dict[str, Any]] = []
    row_number = start_index
    for candidate in _code_explanation_candidates():
        try:
            registry.reject_if_holdout(prompt=candidate["prompt"], holdout_key=candidate["holdout_key"])
        except ValueError:
            continue

        row = {
            "id": f"dpo_code_explanation_no_code_{row_number:06d}",
            "prompt": [
                {"role": "user", "content": candidate["prompt"]},
            ],
            "chosen": [
                {"role": "assistant", "content": candidate["answer"]},
            ],
            "rejected": [
                {"role": "assistant", "content": candidate["rejected"]},
            ],
            "metadata": {
                "category": "general_instruction_following",
                "failure_mode": "code_includes_explanation",
                "difficulty": candidate["difficulty"],
                "template_family": candidate["template_family"],
                "eval_family": candidate["eval_family"],
            },
        }
        rows.append(validate_dpo_row(row))
        if len(rows) >= count:
            return rows
        row_number += 1

    raise ValueError(f"could not build {count} code-explanation DPO rows")


def _arithmetic_candidates() -> Iterable[dict[str, Any]]:
    templates = (
        "Answer with only the number: What is {left} + {right}?",
        "Compute {left} + {right}. Answer with only the number.",
        "What is {left} + {right}? Answer with only the number.",
    )

    for left in range(3, 80):
        for right in range(4, 80):
            answer = left + right
            for template in templates:
                prompt = template.format(left=left, right=right)
                yield {
                    "prompt": prompt,
                    "answer": answer,
                    "rejected": f"The answer is {answer} because {left} plus {right} equals {answer}.",
                    "difficulty": 1 if answer < 50 else 2,
                    "template_family": "direct_qa",
                    "eval_family": "basic_arithmetic_qa",
                    "holdout_key": {
                        "type": "arithmetic",
                        "operation": "add",
                        "operands": [left, right],
                    },
                }


def _capital_city_candidates() -> Iterable[dict[str, Any]]:
    facts = (
        ("Italy", "Rome", "Madrid"),
        ("Spain", "Madrid", "Berlin"),
        ("Germany", "Berlin", "Ottawa"),
        ("Canada", "Ottawa", "Cairo"),
        ("Brazil", "Brasilia", "Nairobi"),
        ("Egypt", "Cairo", "Canberra"),
        ("Kenya", "Nairobi", "Rome"),
        ("India", "New Delhi", "Seoul"),
        ("Australia", "Canberra", "Mexico City"),
        ("South Korea", "Seoul", "Buenos Aires"),
        ("Mexico", "Mexico City", "Ottawa"),
        ("Argentina", "Buenos Aires", "Brasilia"),
    )
    templates = (
        "What is the capital of {country}?",
        "Name the capital city of {country}.",
        "Which city is the capital of {country}?",
    )

    for country, capital, wrong_capital in facts:
        for template in templates:
            prompt = template.format(country=country)
            yield {
                "prompt": prompt,
                "answer": capital,
                "rejected": wrong_capital,
                "difficulty": 1,
                "template_family": "capital_city_direct",
                "eval_family": "capital_city_qa",
                "holdout_key": {
                    "type": "capital_city",
                    "country": country,
                    "answer": capital,
                },
            }


def _clear_sky_color_candidates() -> Iterable[dict[str, Any]]:
    facts = (
        (
            "On a cloudless day, what color does the sky usually appear?",
            "blue",
            "green",
            "cloudless_day_sky_color",
        ),
        (
            "What color is the sky usually at midday when there are no clouds?",
            "blue",
            "red",
            "midday_clear_sky_color",
        ),
        (
            "During clear daytime weather, what color is the sky generally?",
            "blue",
            "black",
            "clear_daytime_sky_color",
        ),
        (
            "In normal daylight with no storm clouds, what color does the sky look?",
            "blue",
            "orange",
            "normal_daylight_sky_color",
        ),
        (
            "What is the usual color of a cloud-free daytime sky?",
            "blue",
            "purple",
            "cloud_free_daytime_sky_color",
        ),
    )

    for prompt, answer, rejected, relation in facts:
        yield {
            "prompt": prompt,
            "answer": answer,
            "rejected": rejected,
            "difficulty": 1,
            "template_family": "sky_color_direct",
            "eval_family": "clear_sky_color_qa",
            "holdout_key": {
                "type": "factual_relation",
                "relation": relation,
                "answer": answer,
            },
            }


def _code_expression_result_candidates() -> Iterable[dict[str, Any]]:
    tasks = (
        ("2 + 3 * 4", "14", "20", "integer_arithmetic_expression", 1),
        ("len([1, 2, 3, 4])", "4", "3", "len_list_expression", 1),
        ("'ab' * 3", "ababab", "ab3", "string_repeat_expression", 1),
        ("sum([5, 7, 9])", "21", "20", "sum_list_expression", 1),
        ("sorted([3, 1, 2])[0]", "1", "3", "sorted_index_expression", 2),
        ("'hello'.upper()", "HELLO", "hello", "string_method_expression", 1),
        ("10 // 3", "3", "3.3333333333333335", "integer_floor_division_expression", 1),
        ("[x * 2 for x in [1, 2, 3]][-1]", "6", "3", "list_comprehension_index_expression", 2),
    )
    templates = (
        "What is the result of this Python expression? Return only the output.\n\n{expression}",
        "Evaluate this Python expression. Return only the result.\n\n{expression}",
    )

    for expression, answer, rejected, expression_key, difficulty in tasks:
        for template in templates:
            prompt = template.format(expression=expression)
            yield {
                "prompt": prompt,
                "answer": answer,
                "rejected": rejected,
                "difficulty": difficulty,
                "template_family": "python_expression_result",
                "eval_family": "code_expression_result",
                "holdout_key": {
                    "type": "code_expression",
                    "expression_key": expression_key,
                    "expression": expression,
                },
            }


def _direct_subtraction_candidates() -> Iterable[dict[str, Any]]:
    templates = (
        "What is {left} - {right}?",
        "Compute {left} - {right}.",
        "Answer with only the number: {left} - {right}",
    )

    for left in range(13, 120):
        for right in range(2, left):
            answer = left - right
            rejected = answer + 1
            for template in templates:
                prompt = template.format(left=left, right=right)
                yield {
                    "prompt": prompt,
                    "answer": answer,
                    "rejected": rejected,
                    "difficulty": 1 if left < 50 else 2,
                    "template_family": "direct_subtraction",
                    "eval_family": "direct_subtraction",
                    "holdout_key": {
                        "type": "arithmetic",
                        "operation": "subtract",
                        "operands": [left, right],
                    },
                }


def _direct_division_candidates() -> Iterable[dict[str, Any]]:
    templates = (
        "What is {left} / {right}?",
        "Compute {left} / {right}.",
        "Answer with only the number: {left} / {right}",
    )

    for right in range(2, 13):
        for answer in range(3, 40):
            left = right * answer
            rejected = answer + 1
            for template in templates:
                prompt = template.format(left=left, right=right)
                yield {
                    "prompt": prompt,
                    "answer": answer,
                    "rejected": rejected,
                    "difficulty": 1 if left < 100 else 2,
                    "template_family": "direct_division",
                    "eval_family": "direct_division",
                    "holdout_key": {
                        "type": "arithmetic",
                        "operation": "divide",
                        "operands": [left, right],
                    },
                }


def _repeat_candidates() -> Iterable[dict[str, Any]]:
    tokens = ("dog", "blue", "yes", "sun", "green", "book", "code", "river")
    templates = (
        "Repeat {token} exactly {count_word} times.",
        'Output "{token}" exactly {count_word} times.',
        "Write {token} exactly {count_word} times and nothing else.",
    )
    count_words = {
        2: "two",
        3: "three",
        4: "four",
        5: "five",
    }

    for token in tokens:
        for count, count_word in count_words.items():
            answer = " ".join([token] * count)
            rejected = f"{answer} {token}"
            for template in templates:
                prompt = template.format(token=token, count_word=count_word)
                yield {
                    "prompt": prompt,
                    "answer": answer,
                    "rejected": rejected,
                    "difficulty": 1 if count <= 3 else 2,
                    "template_family": "repeat_word_count",
                    "eval_family": "repeat_exact_n_times",
                    "holdout_key": {
                        "type": "repeat_exact_n_times",
                        "token": token,
                        "count": count,
                    },
                }


def _list_candidates() -> Iterable[dict[str, Any]]:
    item_sets = (
        ("animals", ("dog", "cat", "horse", "bird", "fish")),
        ("fruits", ("apple", "banana", "pear", "orange", "plum")),
        ("planets", ("Mercury", "Venus", "Earth", "Mars", "Jupiter")),
        ("shapes", ("circle", "square", "triangle", "rectangle", "oval")),
        ("tools", ("hammer", "saw", "wrench", "drill", "level")),
    )
    templates = (
        "List exactly {count_word} {item_type}.",
        "Name exactly {count_word} {item_type}.",
        "Give exactly {count_word} {item_type} and nothing else.",
    )
    count_words = {
        2: "two",
        3: "three",
        4: "four",
    }

    for item_type, items in item_sets:
        for count, count_word in count_words.items():
            answer_items = items[:count]
            rejected_items = items[: count + 1]
            answer = ", ".join(answer_items)
            rejected = ", ".join(rejected_items)
            for template in templates:
                prompt = template.format(count_word=count_word, item_type=item_type)
                yield {
                    "prompt": prompt,
                    "answer": answer,
                    "rejected": rejected,
                    "difficulty": 1 if count <= 3 else 2,
                    "template_family": "list_n_items",
                    "eval_family": "list_exact_n_items",
                    "holdout_key": {
                        "type": "list_exact_n_items",
                        "item_type": item_type,
                        "count": count,
                    },
                }


def _private_company_fact_candidates() -> Iterable[dict[str, Any]]:
    companies = ("Cohere", "Scale AI", "Perplexity", "Mistral AI", "Character.AI", "Runway")
    facts = (
        ("private_revenue", "private revenue", "last week", "private_info_restraint", "$18 million"),
        ("internal_payroll_total", "internal payroll total", "last month", "private_info_restraint", "$42 million"),
        ("unreleased_user_count", "unreleased user count", "yesterday", "unknown_fact_restraint", "12.4 million"),
        ("non_public_customer_count", "non-public customer count", "last quarter", "unknown_fact_restraint", "8,700"),
    )
    templates = (
        "What was {company}'s {fact_label} {time_window}?",
        "Can you tell me {company}'s {fact_label} from {time_window}?",
        "What is the exact {fact_label} for {company} {time_window}?",
    )

    for company in companies:
        for fact_key, fact_label, time_window, category, fabricated_value in facts:
            for template in templates:
                prompt = template.format(company=company, fact_label=fact_label, time_window=time_window)
                yield {
                    "prompt": prompt,
                    "answer": "I do not have access to that private or non-public information.",
                    "rejected": f"{company}'s {fact_label} {time_window} was {fabricated_value}.",
                    "category": category,
                    "difficulty": 2,
                    "template_family": "private_company_fact",
                    "eval_family": "private_or_unverifiable_company_fact",
                    "holdout_key": {
                        "type": "unverifiable_company_fact",
                        "company": company,
                        "fact": fact_key,
                        "time_window": time_window.replace(" ", "_"),
                    },
                }


def _code_generation_candidates() -> Iterable[dict[str, Any]]:
    tasks = (
        {
            "function_name": "multiply",
            "task_key": "multiply_two_numbers",
            "prompt": "Write a Python function named multiply that multiplies two numbers. Return only code.",
            "answer": "def multiply(a, b):\n    return a * b",
            "difficulty": 1,
        },
        {
            "function_name": "is_even",
            "task_key": "is_even_number",
            "prompt": "Write a Python function named is_even that returns True if a number is even. Return only code.",
            "answer": "def is_even(n):\n    return n % 2 == 0",
            "difficulty": 1,
        },
        {
            "function_name": "last_item",
            "task_key": "return_last_item",
            "prompt": "Write a Python function named last_item that returns the last item in a list. Return only code.",
            "answer": "def last_item(items):\n    return items[-1]",
            "difficulty": 1,
        },
        {
            "function_name": "count_items",
            "task_key": "count_items",
            "prompt": "Write a Python function named count_items that returns the length of a list. Return only code.",
            "answer": "def count_items(items):\n    return len(items)",
            "difficulty": 1,
        },
        {
            "function_name": "cube",
            "task_key": "cube_number",
            "prompt": "Write a Python function named cube that returns the cube of a number. Return only code.",
            "answer": "def cube(x):\n    return x * x * x",
            "difficulty": 1,
        },
    )

    for task in tasks:
        yield {
            **task,
            "rejected": f"Here is the function:\n\n{task['answer']}",
            "template_family": "simple_function_generation",
            "eval_family": "code_generation_function",
            "holdout_key": {
                "type": "code_generation",
                "function_name": task["function_name"],
                "function_task": task["task_key"],
            },
        }


def _function_completion_candidates() -> Iterable[dict[str, Any]]:
    tasks = (
        {
            "function_name": "double",
            "signature": "def double(x):",
            "docstring": '"""Return x doubled."""',
            "answer": "return x * 2",
            "task_key": "double_number",
            "difficulty": 1,
        },
        {
            "function_name": "is_empty",
            "signature": "def is_empty(items):",
            "docstring": '"""Return True if the list has no items."""',
            "answer": "return len(items) == 0",
            "task_key": "list_is_empty",
            "difficulty": 1,
        },
        {
            "function_name": "total",
            "signature": "def total(values):",
            "docstring": '"""Return the sum of the values."""',
            "answer": "return sum(values)",
            "task_key": "sum_values",
            "difficulty": 1,
        },
        {
            "function_name": "starts_with_a",
            "signature": "def starts_with_a(text):",
            "docstring": '"""Return True if text starts with the letter a."""',
            "answer": "return text.startswith(\"a\")",
            "task_key": "starts_with_a",
            "difficulty": 1,
        },
    )

    for task in tasks:
        prompt = (
            "Complete this Python function. Return only the function body.\n\n"
            f"{task['signature']}\n"
            f"    {task['docstring']}"
        )
        yield {
            **task,
            "prompt": prompt,
            "rejected": f"This function should return the requested value.\n\n{task['answer']}",
            "template_family": "function_body_completion",
            "eval_family": "function_completion_body_only",
            "holdout_key": {
                "type": "function_completion",
                "function_name": task["function_name"],
            },
        }


def _code_explanation_candidates() -> Iterable[dict[str, Any]]:
    tasks = (
        {
            "function_name": "double",
            "code": "def double(x):\n    return x * 2",
            "answer": "It returns the input value multiplied by two.",
            "operation": "double_number",
            "difficulty": 1,
        },
        {
            "function_name": "is_even",
            "code": "def is_even(n):\n    return n % 2 == 0",
            "answer": "It returns True when the input number is even.",
            "operation": "check_even_number",
            "difficulty": 1,
        },
        {
            "function_name": "total",
            "code": "def total(values):\n    return sum(values)",
            "answer": "It returns the sum of all values in the input list.",
            "operation": "sum_values",
            "difficulty": 1,
        },
        {
            "function_name": "last_item",
            "code": "def last_item(items):\n    return items[-1]",
            "answer": "It returns the final item from the input list.",
            "operation": "return_last_item",
            "difficulty": 1,
        },
    )

    for task in tasks:
        prompt = f"Explain what this Python function does:\n\n{task['code']}"
        yield {
            **task,
            "prompt": prompt,
            "rejected": f"This function does the following:\n\n{task['code']}",
            "template_family": "plain_code_explanation",
            "eval_family": "code_explanation_no_code",
            "holdout_key": {
                "type": "code_explanation",
                "function_name": task["function_name"],
                "operation": task["operation"],
            },
        }


def _validate_family(family: str) -> str:
    if not isinstance(family, str):
        raise TypeError("family must be a string")
    normalized = family.strip().lower()
    if normalized not in DPO_SEED_FAMILIES:
        supported = ", ".join(sorted(DPO_SEED_FAMILIES))
        raise ValueError(f"Unsupported DPO seed family '{family}'. Supported families: {supported}")
    return normalized
